﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ImportForm : Form
    {
        private string fileName;
        //private OleDbConnection discretionaryConnection = new OleDbConnection();
        public ImportForm()
        {
            InitializeComponent();
        }
        public string FileName { get => fileName; set => fileName = value; }
        HashSet<Participant> participantList = new HashSet<Participant>();


        public String UID = "";
        private OleDbConnection connection = new OleDbConnection();

        private void btnImport_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Open Text File";
            openFileDialog.Filter = "Access files|*.MDB;*.accdb";
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {


                    string fileName = openFileDialog.FileName;
                    MessageBox.Show(fileName);

                    connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Persist Security Info=False;";
                    test();
                    richTextBox1.Show();
                    pictureBox2.Show();
                    checkedListBox1.Show();
                    button1.Show();
                    pictureBox3.Show();
                    calculateBtn.Show();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void ImportForm_Load(object sender, EventArgs e)
        {
        }
        public void test()
        {



            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;



                String query = "SELECT * FROM Documents where name like 'sfc%' and FolderName Like 'BASE%' and age Is Not Null and gender Is Not Null ;";

                command.CommandText = query;
                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    
                    checkedListBox1.Items.Add(reader["Name"].ToString());

                }
                connection.Close();

            }
            catch (Exception ex) { MessageBox.Show("opps" + ex); }
        }
    


        private void CalculateBtn_Click(object sender, EventArgs e)
        {
            pictureBox4.Show();
            label1.Show();


            //calc
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void CircularProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void CheckedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                String query = "SELECT * FROM Documents where Name = '" + checkedListBox1.Text + "'";
                UID = checkedListBox1.Text;
                command.CommandText = query;
                OleDbDataReader reader = command.ExecuteReader();
  

                connection.Close();

            }
            catch (Exception ex) { MessageBox.Show("opps" + ex); }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                
                OleDbDataReader reader = command.ExecuteReader();
               

                OleDbCommand command1 = new OleDbCommand();
                command1.Connection = connection;
                String query1 = "SELECT DISTINCT Day FROM DocFoods WHERE DocName = '" + UID + "'";

                command1.CommandText = query1;
                OleDbDataReader reader1 = command1.ExecuteReader();
               

                OleDbCommand command2 = new OleDbCommand();
                command2.Connection = connection;
                String query2 = "SELECT DISTINCT Day FROM DocFoods WHERE DocName = '" + UID + "'";

                command2.CommandText = query2;
                OleDbDataReader reader2 = command2.ExecuteReader();
               

                connection.Close();

            }
            catch (Exception ex) { MessageBox.Show("opps" + ex); }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, true);
            }
        }
    }
    
}
